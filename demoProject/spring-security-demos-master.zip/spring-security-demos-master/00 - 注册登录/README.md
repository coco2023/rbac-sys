## 使用手册

1、执行 `mvn spring-boot:run`

2、访问 http://localhost:8080/

3、点击 `登录`

> 账号：anoyi
> 密码：anoyi